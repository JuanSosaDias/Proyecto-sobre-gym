package com.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Interacciones {
    private Map<Proteina, List<Proteina>> interacciones;

    public Interacciones() {
        this.interacciones = new HashMap<>();
    }

    public void agregarProteina(Proteina proteina, String intera) {
        if (!interacciones.containsKey(proteina)) {
            interacciones.put(proteina, new ArrayList<>());
        }
    }

    public void agregarInteracion(Proteina proteina1, Proteina proteina2) {
        if (interacciones.containsKey(proteina1) && interacciones.containsKey(proteina2)) {
            interacciones.get(proteina1).add(proteina2);
            interacciones.get(proteina2).add(proteina1); // Considerar la interacción como bidireccional
        } else {
            //System.out.println("No se tienen esas proteínas por ahora...");
        }
    }


    public void mostrarGrafo() {
        System.out.println("GRAFO DE PROTEÍNAS: ");
        for (Map.Entry<Proteina, List<Proteina>> entry : interacciones.entrySet()) {
            Proteina proteina = entry.getKey();
            List<Proteina> vecinos = entry.getValue();
            System.out.print(proteina.getNombre() +", "+"::::::::>>>>>>>");
            for (Proteina vecino : vecinos) {
                System.out.print(vecino.getNombre() + ", ");
            }
            System.out.println();
        }
    }
    
}
