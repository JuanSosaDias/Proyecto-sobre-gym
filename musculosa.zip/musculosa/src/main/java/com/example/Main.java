package com.example;

/*
Este proyecto consta de Nodos (Proteínas) y Aristas (Conexiones),
lo que hace es mostrar el nombre de cada proteína y cómo se conectan con otras para
mejorar cada músculo.
*/

public class Main {
    public static void main(String[] args) {
        String[] lineasArchivo = ManejadorArchivosGenerico.leerArchivo("musculosa/src/main/java/com/example/Proteinas.txt", false);

        Interacciones red = new Interacciones();
        Separador separador = new Separador(lineasArchivo);
        

        System.out.println();

        red.mostrarGrafo();
    }
}
