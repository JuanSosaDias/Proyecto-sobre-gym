package com.example;

public class Proteina {
    private String nombre;
    private String funcion;

    public Proteina(String nombre, String funcion) {
        this.nombre = nombre;
        this.funcion = funcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getFuncion() {
        return funcion;
    }

}
