package com.example;

public class Separador {
    public Separador ( String [] lineasArchivo) {
        Interacciones red = new Interacciones();

        for (String linea : lineasArchivo) {
            String[] partes = linea.split(",");
            if (partes.length == 3) {
                String nombre = partes[0].trim();
                String funcion = partes[1].trim();
                String interacciones = partes[2].trim();
                Proteina proteina = new Proteina(nombre, funcion);
                red.agregarProteina(proteina, interacciones);
                System.out.println("Proteína agregada: " + nombre + " - " + funcion);
            }
        }
    }
}
ME FALTA SOLO EL FOR PARA AGREGAR CADA UNO A LA RED